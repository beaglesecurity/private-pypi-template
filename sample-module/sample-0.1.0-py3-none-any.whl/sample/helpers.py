def get_answer():
    """Get an answer."""
    return True
